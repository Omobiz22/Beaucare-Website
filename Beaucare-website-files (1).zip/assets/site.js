// Beaucare Ltd - site behaviour: menu, forms, WhatsApp fallback, analytics events.
(function () {
  var cfg = window.BEAUCARE || {};

  // Mobile menu
  var btn = document.querySelector('.menu-btn');
  var nav = document.getElementById('nav');
  if (btn && nav) {
    btn.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open);
      btn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });
  }
  // Services dropdown
  document.querySelectorAll('.sub-toggle').forEach(function (t) {
    t.addEventListener('click', function (e) {
      e.stopPropagation();
      var li = t.parentElement;
      var open = li.classList.toggle('open');
      t.setAttribute('aria-expanded', open);
    });
  });
  document.addEventListener('click', function (e) {
    document.querySelectorAll('.has-sub.open').forEach(function (li) {
      if (!li.contains(e.target)) { li.classList.remove('open'); li.querySelector('.sub-toggle').setAttribute('aria-expanded', 'false'); }
    });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') document.querySelectorAll('.has-sub.open').forEach(function (li) { li.classList.remove('open'); var t = li.querySelector('.sub-toggle'); t.setAttribute('aria-expanded', 'false'); t.focus(); });
  });

  // Analytics events (only fire when Google Analytics is installed)
  function track(name, params) { if (typeof window.gtag === 'function') window.gtag('event', name, params || {}); }
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-track]');
    if (!a) return;
    var kind = a.getAttribute('data-track');
    track(kind === 'whatsapp' ? 'whatsapp_click' : kind === 'phone' ? 'phone_click' : 'email_click', { link_url: a.href, page_path: location.pathname });
  });

  // Pre-select service on the quote form from ?service=slug
  var params = new URLSearchParams(location.search);
  var preset = params.get('service');
  var serviceSelect = document.getElementById('f-service');
  if (preset && serviceSelect) {
    var wanted = preset.replace(/-/g, ' ').toLowerCase();
    Array.prototype.forEach.call(serviceSelect.options, function (o) {
      var t = o.text.toLowerCase().replace(/[^a-z ]/g, '');
      if (t && wanted.split(' ').every(function (w) { return w.length < 3 || t.indexOf(w) > -1; })) serviceSelect.value = o.value;
    });
  }

  // Forms
  function labelFor(form, name) {
    var el = form.querySelector('[name="' + name + '"]');
    if (!el) return name;
    var fs = el.closest('fieldset');
    if (fs) return fs.querySelector('legend').textContent.replace(/\*|\(optional\)/g, '').trim();
    var l = form.querySelector('label[for="' + el.id + '"]');
    return l ? l.textContent.replace(/\*|\(optional\)/g, '').trim() : name;
  }
  function collect(form) {
    var data = new FormData(form);
    var out = [];
    data.forEach(function (v, k) { if (k === 'botcheck' || k === 'consent' || !String(v).trim()) return; out.push([k, labelFor(form, k), String(v).trim()]); });
    return out;
  }
  function waMessage(form) {
    var intro = { quote: 'Hello Beaucare Ltd. I would like a cleaning quotation.', commercial: 'Hello Beaucare Ltd. I would like to discuss commercial cleaning.', contact: 'Hello Beaucare Ltd.', careers: 'Hello Beaucare Ltd. I would like to register interest in working with you.' }[form.dataset.form] || 'Hello Beaucare Ltd.';
    return intro + '\n\n' + collect(form).map(function (r) { return r[1] + ': ' + r[2]; }).join('\n');
  }
  function validate(form) {
    var first = null;
    form.querySelectorAll('[required]').forEach(function (el) {
      var ok = true;
      if (el.type === 'radio') ok = !!form.querySelector('[name="' + el.name + '"]:checked');
      else if (el.type === 'checkbox') ok = el.checked;
      else ok = el.value.trim() !== '' && el.checkValidity();
      if (el.type === 'tel' && el.value.trim()) ok = ok && el.value.replace(/[^0-9]/g, '').length >= 10;
      var err = document.getElementById(el.id + '-err');
      el.setAttribute('aria-invalid', ok ? 'false' : 'true');
      if (err) {
        err.hidden = ok;
        err.textContent = ok ? '' : (el.type === 'email' ? 'Please enter a valid email address.' : el.type === 'tel' ? 'Please enter a phone number we can reach you on.' : 'This field is required.');
        if (!ok) el.setAttribute('aria-describedby', err.id);
      }
      if (!ok && !first) first = el;
    });
    var email = form.querySelector('[type=email]');
    if (email && email.value.trim() && !email.checkValidity()) {
      var e2 = document.getElementById(email.id + '-err');
      if (e2) { e2.hidden = false; e2.textContent = 'Please enter a valid email address.'; }
      email.setAttribute('aria-invalid', 'true');
      if (!first) first = email;
    }
    return first;
  }
  function status(form, cls, html) {
    var s = form.querySelector('.form-status');
    s.className = 'form-status ' + cls; s.innerHTML = html; s.hidden = false;
    s.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
  function waUrl(form) { return 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent(waMessage(form)); }

  document.querySelectorAll('.js-form').forEach(function (form) {
    var waBtn = form.querySelector('[data-wa-from-form]');
    if (waBtn) waBtn.addEventListener('click', function () {
      track('whatsapp_click', { form: form.dataset.form, page_path: location.pathname });
      window.open(waUrl(form), '_blank', 'noopener');
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var bad = validate(form);
      if (bad) { bad.focus(); status(form, 'bad', 'Please check the highlighted fields.'); return; }
      if (form.querySelector('[name=botcheck]').checked) return;
      // No form service configured yet: be honest and offer WhatsApp.
      if (!cfg.formKey) {
        status(form, 'info', 'Online form delivery is not switched on yet, so this form cannot send your details by itself. Please tap below to send the same details to us on WhatsApp.<br><br><a class="btn btn-wa" target="_blank" rel="noopener" href="' + waUrl(form) + '">Send on WhatsApp</a>');
        return;
      }
      var submit = form.querySelector('[type=submit]');
      submit.disabled = true; submit.textContent = 'Sending...';
      var payload = { access_key: cfg.formKey, subject: form.dataset.subject, from_name: 'Beaucare website', botcheck: false };
      collect(form).forEach(function (r) { payload[r[1]] = r[2]; });
      var emailField = form.querySelector('[name=email]');
      if (emailField && emailField.value.trim()) payload.replyto = emailField.value.trim();
      fetch('https://api.web3forms.com/submit', { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(payload) })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (!res.success) throw new Error(res.message || 'failed');
          track('generate_lead', { form: form.dataset.form });
          status(form, 'ok', '<strong>Thank you. Your details have been sent to Beaucare.</strong> We will be in touch using your preferred contact method. For a faster reply, you can also <a target="_blank" rel="noopener" href="' + waUrl(form) + '">send the same details on WhatsApp</a>.');
          form.reset();
        })
        .catch(function () {
          status(form, 'bad', 'Sorry, your message could not be sent just now. Please <a target="_blank" rel="noopener" href="' + waUrl(form) + '">send it on WhatsApp</a> or email <a href="mailto:' + cfg.email + '">' + cfg.email + '</a>.');
        })
        .finally(function () { submit.disabled = false; submit.textContent = 'Send again'; });
    });
  });
})();
